export const carsMarrakech = [
  {
    title: 'Hyundai i10 – Hay Charaf',
    price: 'MAD150/day',
    image: require('../assets/1.jpg'),
    rating: 4.8,
  },
  {
    title: 'Fiat 500 Sport',
    price: '250 MAD / jour',
    rating: '4.9',
    image: require('../assets/2.jpg'),
    description: 'Petite citadine idéale pour la ville.'
  },
  {
    title: 'Dacia Logan – Targa',
    price: 'MAD200/day',
    image: require('../assets/2.jpg'),
    rating: 4.7,
  },
  {
    title: 'Kia Picanto – Marina',
    price: 'MAD170/day',
    image: require('../assets/3.jpg'),
    rating: 4.9,
  },
  {
    title: 'Hyundai i10 – Hay Charaf',
    price: 'MAD150/day',
    image: require('../assets/1.jpg'),
    rating: 4.8,
  },
  {
    title: 'Dacia Logan – Targa',
    price: 'MAD200/day',
    image: require('../assets/2.jpg'),
    rating: 4.7,
  },
  {
    title: 'Kia Picanto – Marina',
    price: 'MAD170/day',
    image: require('../assets/3.jpg'),
    rating: 4.9,
  },
  
];

export const carsTanger = [
  {
    title: 'Kia Picanto – Marina',
    price: 'MAD170/day',
    image: require('../assets/3.jpg'),
    rating: 4.9,
  },
  {
    title: 'Dacia Logan – Targa',
    price: 'MAD200/day',
    image: require('../assets/2.jpg'),
    rating: 4.7,
  },
  {
    title: 'Hyundai i10 – Hay Charaf',
    price: 'MAD150/day',
    image: require('../assets/1.jpg'),
    rating: 4.8,
  },
  {
    title: 'Dacia Logan – Targa',
    price: 'MAD200/day',
    image: require('../assets/2.jpg'),
    rating: 4.7,
  },
  {
    title: 'Kia Picanto – Marina',
    price: 'MAD170/day',
    image: require('../assets/3.jpg'),
    rating: 4.9,
  },
];
